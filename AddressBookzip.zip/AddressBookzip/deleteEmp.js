import { getElementById } from "./script.js";

export function deleteEmployee(button) {
    var row = button.parentNode.parentNode;
    var table = getElementById("employeeTable");
    var rowIndex = row.rowIndex;


    table.deleteRow(rowIndex);

    refreshSerialNumbers();
}

function refreshSerialNumbers() {
    var table = getElementById("employeeTable");
    var rows = table.getElementsByTagName("tr");

    for (var i = 1; i < rows.length; i++) {
        rows[i].cells[0].innerHTML = i;
    }
}