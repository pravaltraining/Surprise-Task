import { addEmployee } from "./addEmp.js";
import { deleteEmployee } from "./deleteEmp.js";
import { editEmployee, updateEmployee } from "./editEmp.js";

export function getElementById(element){
    return document.getElementById(element);
}

function setDisplayStyle(elementId, value) {
    getElementById(elementId).style.display = value;
}
export function setDisplayBlock(element){
    setDisplayStyle(element, "block");
}
export function setDisplayNone(element){
   setDisplayStyle(element, "none");
}
function addEventListener(element,event,setFunction){
    getElementById(element).addEventListener(event,setFunction)
}
function addEventClick(element,setFunction){
    addEventListener(element,"click",setFunction)
}




addEventClick("addEmpBtn", addEmployeeBtn);
// document.getElementById("addEmpBtn").addEventListener("click" ,
function addEmployeeBtn(){
    resetErrorMessages();
    setDisplayBlock("popupForm");
    setDisplayNone("update");
    setDisplayBlock("add");
    setDisplayBlock("addTittle");
    setDisplayNone("editTittle");
    setDisplayBlock("blur");
    resetForm();
    
}
addEventClick("cancel", addCancelBtn);
// document.getElementById("cancel").addEventListener("click" ,
function addCancelBtn(){
    setDisplayNone("popupForm");
    setDisplayNone("blur");
}

addEventClick("add",addEmployee);
addEventClick("update",updateEmployee);
// document.getElementById("add").addEventListener("click" ,addEmployee)
// document.getElementById("update").addEventListener("click" ,updateEmployee)
addEventClick("employeeTable",addEvent);
// document.getElementById("employeeTable").addEventListener("click", 
function addEvent(event) {
    var target = event.target;

  
    if (target.tagName == "BUTTON" && (target.textContent == "Edit" || target.textContent == "Delete")) {
        if(target.textContent == "Edit"){
            editEmployee(target)
        }
        else{
            deleteEmployee(target) 
        }
    }
}

function resetForm(){
    getElementById("formFirstName").value="";
    getElementById("formLastName").value="";
    getElementById("formEmail").value="";
    getElementById("formSalary").value="";
    getElementById("formDate").value="";
}
export function resetErrorMessages(){
    getElementById("firstNameError").innerHTML="";
    getElementById("lastNameError").innerHTML="";
    getElementById("emailError").innerHTML="";
    getElementById("salaryError").innerHTML="";
    getElementById("dateError").innerHTML="";
}
