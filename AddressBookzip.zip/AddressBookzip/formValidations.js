import { getElementById } from "./script.js";

// function addEventInput(element,setFunction){
//     addEventListener(element,"input",setFunction)
// }
// addEventInput("formFirstName",validateFirstName)
// addEventInput("formLastName",validateLastName)
// addEventInput("formEmail",validateEmail)
// addEventInput("formSalary",validateSalary)
// addEventInput("formDate",validateDate)
getElementById("formFirstName").addEventListener("input",validateFirstName);
getElementById("formLastName").addEventListener("input",validateLastName);
getElementById("formEmail").addEventListener("input",validateEmail);
getElementById("formSalary").addEventListener("input",validateSalary);
getElementById("formDate").addEventListener("input",validateDate);
function validateFirstName() {
    var firstName = getElementById("formFirstName").value;
    var errorSpan = getElementById("firstNameError");
    if (firstName.trim() == "") {
        errorSpan.innerHTML = "Please enter First Name";
    } else {
        errorSpan.innerHTML = ""; 
    }
}

function validateLastName() {
    var lastName = getElementById("formLastName").value;
    var errorSpan = getElementById("lastNameError");
    if (lastName.trim() == "") {
        errorSpan.innerHTML = "Please enter Last Name";
    } else {
        errorSpan.innerHTML = "";
    }
}

function validateEmail() {
    var email = getElementById("formEmail").value;
    var errorSpan = getElementById("emailError");
    if (email.trim() == "") {
        errorSpan.innerHTML = "Please enter Email";
    } else if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)){
        errorSpan.innerHTML = "Please enter a valid Email";
    }else {
        errorSpan.innerHTML = "";
    }
}

function validateSalary() {
    var salary = getElementById("formSalary").value;
    var errorSpan = getElementById("salaryError");
    if (!/^\d/.test(salary)) {
        errorSpan.innerHTML = "Please enter a valid Salary in dollars";
    } else {
        errorSpan.innerHTML = "";
    }
}
function validateDate() {
    var date = getElementById("formDate").value;
    var errorSpan = getElementById("dateError");
    if (date.trim() == "") {
        errorSpan.innerHTML = "Please enter Date";
    } else {
        errorSpan.innerHTML = "";
    }
}
export function validateForm() {
    validateFirstName();
    validateLastName();
    validateEmail();
    validateSalary();
    validateDate();

    var errorSpans = document.getElementsByClassName("error");
    for (var i = 0; i < errorSpans.length; i++) {
        if (errorSpans[i].innerHTML.trim() !== "") {
            return false;
        }
    }

    return true;
}