import { getElementById, resetErrorMessages, setDisplayBlock, setDisplayNone } from "./script.js";

var selectedRow = null;

export function editEmployee(button){
    resetErrorMessages();
    setDisplayBlock("popupForm");
    setDisplayBlock("update");
    setDisplayNone("add");
    setDisplayNone("addTittle");
    setDisplayBlock("editTittle");
    setDisplayBlock("blur");
    var row = button.parentNode.parentNode;
    selectedRow = row;
    getElementById("formFirstName").value = row.cells[1].innerHTML;
    getElementById("formLastName").value = row.cells[2].innerHTML;
    getElementById("formEmail").value = row.cells[3].innerHTML;
    getElementById("formSalary").value = row.cells[4].innerHTML;
    getElementById("formDate").value = row.cells[5].innerHTML;
}
export function updateEmployee(){
    setDisplayNone("popupForm");
    setDisplayNone("blur");
    if (selectedRow) {
        selectedRow.cells[1].innerHTML = getElementById("formFirstName").value;
        selectedRow.cells[2].innerHTML = getElementById("formLastName").value;
        selectedRow.cells[3].innerHTML = getElementById("formEmail").value;
        selectedRow.cells[4].innerHTML = getElementById("formSalary").value;
        selectedRow.cells[5].innerHTML =getElementById("formDate").value;
        selectedRow = null;
    }
}
